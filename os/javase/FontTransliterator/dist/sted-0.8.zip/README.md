FontTransliterator
==================

Universal Transliterator for Global Languages

STED - README
========================

Thank you for downloading STED!

STED PLATFORM
========================
Developed and Tested on JDK 1.7.0 on Ubuntu Linux.
    ** IMPORTANT: **
JDK 1.7.0 or later is required for running STED 0.80 or later.

Installing STED
========================
Unzip the dowloaded zip file, into a folder.
    ** UNIX: **
    Edit 'bin/sted.sh' to SET JAVA_HOME etc., and run 'sted.sh' from bin folder.
    ** WINDOWS: **
    Edit 'bin/sted.bat' to SET JAVA_HOME etc., and run 'sted.bat' from bin folder.

Uninstalling STED
==========================
  To uninstall STED, simply delete the contents of the STED home installation directory.

Licensing STED
==========================
Please read License.txt that was bundled with STED for licensing terms.

Contact STED
=======================
  IntelliBitz Technologies
  http://androidrocks.googlecode.com
  http://www.intellibitz.com
  http://groups.google.com/group/etoe
  http://sted.sourceforge.net
  sted@intellibitz.com


